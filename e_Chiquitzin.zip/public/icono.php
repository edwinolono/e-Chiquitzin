<!DOCTYPE html>
<html lang="es">
<head>
    <title>e-Chiquitzin</title>
    <meta name="author" content="Equipo 5">
    <meta name="keywords" content="HTML5, CSS3, PHP 7.4, MySQL 5.7, PHPMyAdmin, Apache">
    <meta name="copyright" content="Equipo 5 2021">
    <meta name="description" content="Aplicación Web de aprendizaje de matemáticas para niños">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/css/paginaInformativa/icono.png" type="image/x-icon">
    

