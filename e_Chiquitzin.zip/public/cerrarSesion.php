<?php 
    session_destroy();

    include 'paginaComienzo.php';
?>