<?php include "icono.php"; ?>
        <link rel="stylesheet" href="/css/headerAlumno/headerAlumno.css">
        <link rel="stylesheet" href="/css/menuAlumno/menuAlumno.css">
    </head>
    <body>
        <header>
                <div id="nombreAplicacion">e-Chiquitzin</div>
                <div class="anclajes">
                    <!--<a href="./menuAlumno.php">Estadísticas</a>-->
                    <a href="./menuAlumno.php">Inicio</a>
                    <a href="./paginaAyuda.php">Ayuda</a>
                    <a href="./cerrarSesion.php">Cerrar Sesión</a>
                </div>
        </header>