<?php include "./icono.php"; ?>

    <link rel="stylesheet" href="/css/paginaComienzo/paginaComienzo.css">
    
</head>
<body>
    <div id="contenedorPrincipal">
        <div id="title">e-Chikitzin</div>
        <div id="container">
            <div class="option">
                <div class="optionTitle">Iniciar Sesi&oacute;n</div>
                <div class="optionDescription">Inicia sesi&oacute;n y sigue aprendiendo!</div>
                <a class="boton" href="paginaInicioSesion.php">Iniciar sesión</a>
            </div>
            <div class="option">
                <div class="optionTitle">Registrarse</div>
                <div class="optionDescription">&Uacute;nete a e-Chiquitzin y aprende divierti&eacute;ndote</div>
                <a class="boton" href="paginaRegistro.php">Registrarse</a>
            </div>
        </div>
    </div>
</body>
</html>